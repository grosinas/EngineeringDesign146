package com.droiduino.TrobeApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TrashDK extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trash_dk);
        //making buttons
        final Button backMain = findViewById(R.id.backMain);
        backMain.setEnabled(true);
        final Button openPMD1 = findViewById(R.id.openPMD1);
        openPMD1.setEnabled(true);
        final Button openOther1 = findViewById(R.id.openOther1);
        openOther1.setEnabled(true);
        final Button openOther2 = findViewById(R.id.openOther2);
        openOther2.setEnabled(true);
        final Button openAluminium = findViewById(R.id.openAluminium);
        openAluminium.setEnabled(true);
        final Button openFilterCoffee = findViewById(R.id.openFilterCoffee);
        openFilterCoffee.setEnabled(true);
        final Button openDirt = findViewById(R.id.openDirt);
        openDirt.setEnabled(true);
        final Button openTea = findViewById(R.id.openTea);
        openTea.setEnabled(true);
        final Button openBeerCap = findViewById(R.id.openBeerCap);
        openBeerCap.setEnabled(true);
        final Button openDeodorant = findViewById(R.id.openDeodorant);
        openDeodorant.setEnabled(true);
        final Button openDrinkCarton = findViewById(R.id.openDrinkCarton);
        openDrinkCarton.setEnabled(true);


        //on click of back button, you go back to main activity
        backMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Move to adapter list
//                Intent intent = new Intent(TrashDK.this, MainActivity.class);
//                startActivity(intent);
                finish();
            }
        });
        //on click of OpenPMD{number} button, <Open PMD> message sent to arduino
        openPMD1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cmdText = null;
                // Command to turn on LED on Arduino. Must match with the command in Arduino code
                cmdText = "<Open PMD>";
                // Send command to Arduino board
                connectedThread.write(cmdText);
            }
        });
        //on click of other button
        openOther1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cmdText = null;
                // Command to turn on LED on Arduino. Must match with the command in Arduino code
                cmdText = "<Open Other>";
                // Send command to Arduino board
                connectedThread.write(cmdText);
            }
        });
        openOther2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cmdText = null;
                // Command to turn on LED on Arduino. Must match with the command in Arduino code
                cmdText = "<Open Other>";
                // Send command to Arduino board
                connectedThread.write(cmdText);
            }
        });
        openAluminium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cmdText = null;
                // Command to turn on LED on Arduino. Must match with the command in Arduino code
                cmdText = "<Open Other>";
                // Send command to Arduino board
                connectedThread.write(cmdText);
            }
        });
        openFilterCoffee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cmdText = null;
                // Command to turn on LED on Arduino. Must match with the command in Arduino code
                cmdText = "<Open Other>";
                // Send command to Arduino board
                connectedThread.write(cmdText);
            }
        });
        openDirt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cmdText = null;
                // Command to turn on LED on Arduino. Must match with the command in Arduino code
                cmdText = "<Open Other>";
                // Send command to Arduino board
                connectedThread.write(cmdText);
            }
        });
        openTea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cmdText = null;
                // Command to turn on LED on Arduino. Must match with the command in Arduino code
                cmdText = "<Open Other>";
                // Send command to Arduino board
                connectedThread.write(cmdText);
            }
        });
        openBeerCap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cmdText = null;
                // Command to turn on LED on Arduino. Must match with the command in Arduino code
                cmdText = "<Open PMD>";
                // Send command to Arduino board
                connectedThread.write(cmdText);
            }
        });
        openDeodorant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cmdText = null;
                // Command to turn on LED on Arduino. Must match with the command in Arduino code
                cmdText = "<Open Other>";
                // Send command to Arduino board
                connectedThread.write(cmdText);
            }
        });
        openDrinkCarton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cmdText = null;
                // Command to turn on LED on Arduino. Must match with the command in Arduino code
                cmdText = "<Open PMD>";
                // Send command to Arduino board
                connectedThread.write(cmdText);
            }
        });


    }
}